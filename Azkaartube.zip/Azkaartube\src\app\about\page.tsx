"use client";

export default function About() {
  return (
    <main className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">About Us</h1>
      <p className="mb-2">
        Welcome to AzkaarTube! 🎬 Ye platform aapko latest educational,
        motivational aur entertainment videos ek hi jagah par provide karta hai.
      </p>
      <p>
        Hamara mission hai ke viewers ko safe, ad-free aur easy-to-use
        environment provide kiya jaye jahan wo apna pasandida content enjoy kar
        saken. Hum videos ke sath extra description aur useful notes bhi add
        karte hain taake knowledge aur zyada ho.
      </p>
    </main>
  );
}
