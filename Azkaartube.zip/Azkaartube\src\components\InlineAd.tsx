"use client";

import AdSense from "./AdSense";

interface InlineAdProps {
  adSlot: string;
}

const InlineAd = ({ adSlot }: InlineAdProps) => {
  return (
    <div className="my-6 flex justify-center">
      <AdSense adSlot={adSlot} />
    </div>
  );
};

export default InlineAd;
