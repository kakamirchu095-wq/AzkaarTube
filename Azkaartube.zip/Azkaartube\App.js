import React, { useRef, useState, useEffect } from 'react';
import { View, FlatList, Dimensions, Platform, StatusBar, SafeAreaView } from 'react-native';
import Video from 'react-native-video';
import WebView from 'react-native-webview';

const videos = [
  { id: '1', url: 'https://www.example.com/video1.mp4' },
  { id: '2', url: 'https://www.example.com/video2.mp4' },
  { id: '3', url: 'https://www.example.com/video3.mp4' },
];

export default function App() {
  const windowHeight = Dimensions.get('window').height;
  const videoRefs = useRef([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const nextIndex = currentIndex + 1;
    if (videos[nextIndex] && videoRefs.current[nextIndex]) {
      videoRefs.current[nextIndex].seek(0);
    }
  }, [currentIndex]);

  const renderItem = ({ item, index }) => (
    <Video
      ref={el => videoRefs.current[index] = el}
      source={{ uri: item.url }}
      style={{ height: windowHeight, width: '100%' }}
      resizeMode="cover"
      repeat
      paused={currentIndex !== index}
      controls={false}
      ignoreSilentSwitch="ignore"
      playInBackground={false}
      playWhenInactive={false}
      onLoad={() => {
        const next = videoRefs.current[index + 1];
        if(next) next.seek(0);
      }}
    />
  );

  const onViewableItemsChanged = useRef(({ viewableItems }) => {
    if(viewableItems.length > 0){
      setCurrentIndex(viewableItems[0].index);
    }
  });

  const viewConfigRef = useRef({ viewAreaCoveragePercentThreshold: 80 });

  return (
    <SafeAreaView style={{ flex: 1, marginTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0 }}>
      <FlatList
        data={videos}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={onViewableItemsChanged.current}
        viewabilityConfig={viewConfigRef.current}
      />
      <WebView
        source={{ uri: 'https://azkaartube.vercel.app/' }}
        originWhitelist={['*']}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        style={{ display: 'none' }}
      />
    </SafeAreaView>
  );
}
