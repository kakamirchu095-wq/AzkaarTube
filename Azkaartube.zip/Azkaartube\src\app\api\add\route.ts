import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const serviceKey = process.env.SUPABASE_SERVICE_KEY;
if (!serviceKey) {
  console.warn('SUPABASE_SERVICE_KEY not set – /api/add will fail in server');
}

const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL ?? '', serviceKey ?? '');

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { url, parsed } = body || {};
    if (!url || !parsed) return NextResponse.json({ error: 'Missing payload' }, { status: 400 });

    // basic server-side validation
    if (typeof url !== 'string') return NextResponse.json({ error: 'Invalid url' }, { status: 400 });

    const payload = {
      url,
      provider: parsed.provider ?? null,
      embed_url: parsed.embed_url ?? url,
      thumb_url: parsed.thumb_url ?? null,
      title: parsed.title ?? null,
      meta: parsed
    };

    const { data, error } = await supabaseAdmin.from('videos').insert([payload]).select().single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    return NextResponse.json({ ok: true, record: data });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Insert error' }, { status: 500 });
  }
}
