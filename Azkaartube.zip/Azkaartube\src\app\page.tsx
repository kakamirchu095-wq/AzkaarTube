'use client';

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Head from 'next/head';
import { useSwipeable } from 'react-swipeable';
import { createClient } from '@supabase/supabase-js';
import { motion, AnimatePresence } from 'framer-motion';

/* --------------------
   Supabase (singleton to avoid multiple GoTrueClient instances in same browser)
   -------------------- */
const supabase = (() => {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  if (typeof window === 'undefined') return createClient(url, key);
  if (!(window as any).__AZ_SUPABASE_CLIENT) {
    (window as any).__AZ_SUPABASE_CLIENT = createClient(url, key);
  }
  return (window as any).__AZ_SUPABASE_CLIENT;
})();

/* --------------------
   Types & Constants
   -------------------- */
type Category =
  | 'Quran'
  | 'Hadith'
  | 'Lectures'
  | 'Nasheeds'
  | 'Music'
  | 'Education'
  | 'News'
  | 'Sports'
  | 'Comedy'
  | 'Technology'
  | 'Kids'
  | 'Documentary'
  | 'Religious'
  | 'Other';

type Video = {
  id: any;
  title?: string;
  video_link?: string;
  embed_url?: string;
  thumbnail_url?: string;
  platform?: string;
  category?: Category | string;
  created_at?: string;
};

const ALL_CATEGORIES: Category[] = [
  'Quran','Hadith','Lectures','Nasheeds','Music','Education','News','Sports','Comedy','Technology','Kids','Documentary','Religious','Other'
];

const BRAND = {
  primaryFrom: '#0066FF',
  primaryTo: '#7C4DFF',
  accentFrom: '#FF7A59',
  accentTo: '#FF4D8D',
};

/* --------------------
   Helpers
   -------------------- */
function useLocalStorage<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(initial);
  useEffect(() => {
    try { const raw = localStorage.getItem(key); if (raw) setState(JSON.parse(raw) as T); } catch {}
  }, [key]);
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(state)); } catch {} }, [key, state]);
  return [state, setState] as const;
}

function normalizeId(id: any) { try { return String(id); } catch { return String(id ?? ''); } }
function extractYouTubeId(link?: string) {
  if (!link) return null;
  try {
    const l = link.trim();
    const m = l.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([A-Za-z0-9_-]{6,})/);
    return m ? m[1] : null;
  } catch { return null; }
}
function extractVimeoId(link?: string) {
  if (!link) return null;
  try {
    const m = link?.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    return m ? m[1] : null;
  } catch { return null; }
}
function resolveEmbedUrl(raw: string | undefined, autoplay = false) {
  const append = `enablejsapi=1&modestbranding=1&rel=0&autoplay=${autoplay ? '1' : '0'}`;
  if (!raw) return '';
  const link = raw.trim();
  try {
    const yt = extractYouTubeId(link);
    if (yt) return `https://www.youtube.com/embed/${yt}?${append}`;
    if (/youtube\.com\/embed\//.test(link)) return link.includes('?') ? `${link}&${append}` : `${link}?${append}`;
    const vimeo = extractVimeoId(link);
    if (vimeo) return `https://player.vimeo.com/video/${vimeo}?${append}`;
    const dm = link.match(/dailymotion\.com\/(?:video|hub)\/(\w+)/);
    if (dm) return `https://www.dailymotion.com/embed/video/${dm[1]}?${append}`;
    if (/^https?:\/\//.test(link)) return link.includes('?') ? `${link}&${append}` : `${link}?${append}`;
    if (/^[A-Za-z0-9_-]{6,}$/.test(link)) return `https://www.youtube.com/embed/${link}?${append}`;
  } catch {}
  return link;
}

/* --------------------
   YouTube API loader (singleton)
   -------------------- */
let YT_API_LOADING: Promise<void> | null = null;
function loadYouTubeAPI() {
  if (typeof window === 'undefined') return Promise.reject();
  if ((window as any).YT && (window as any).YT.Player) return Promise.resolve();
  if (YT_API_LOADING) return YT_API_LOADING;
  YT_API_LOADING = new Promise((resolve) => {
    const existing = (window as any).onYouTubeIframeAPIReady;
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    (window as any).onYouTubeIframeAPIReady = () => { try { if (typeof existing === 'function') existing(); } catch {} resolve(); };
    document.body.appendChild(tag);
  });
  return YT_API_LOADING;
}

/* --------------------
   Small icons
   -------------------- */
const IconShorts = ({ size = 20 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
    <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9zm1 13.5v-6l4 3-4 3z" fill="currentColor" />
  </svg>
);

/* --------------------
   CategoriesBar
   -------------------- */
const CategoriesBar = React.memo(function CategoriesBar({ categories, selected, onSelect, compact = false }: { categories: string[]; selected?: string | null; onSelect: (c: string | null) => void; compact?: boolean; }) {
  const uniqueCats = useMemo(() => {
    const set = new Set<string>();
    categories.forEach((c) => {
      try { const s = (c || '').toString().trim(); if (s) set.add(s); } catch {}
    });
    return Array.from(set);
  }, [categories]);

  return (
    <div className={`w-full overflow-x-auto py-${compact ? '1' : '2'} px-3`} role="navigation" aria-label="Categories">
      <div className="flex gap-2 items-center">
        <button onClick={() => onSelect(null)} className={`whitespace-nowrap px-3 py-1 rounded-full text-sm font-semibold transition-shadow ${selected === null ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-lg' : 'bg-gray-800 text-gray-300 hover:scale-[1.02]'}`}>All</button>
        {uniqueCats.map((cat) => (
          <button key={cat} onClick={() => onSelect(cat)} className={`whitespace-nowrap px-3 py-1 rounded-full text-sm font-medium transition-transform ${selected === cat ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow' : 'bg-gray-800 text-gray-300 hover:scale-[1.02]'}`}>{cat}</button>
        ))}
      </div>
    </div>
  );
});

/* --------------------
   Metadata & Add helpers (from original add system)
   -------------------- */
const adultKeywords = /(sex|porn|xxx|nude|naked|adult|hentai|camgirl|camboy|pornhub|xvideos|xhamster|redtube|xnxx|brazzers)/i;
const adultDomains = ['pornhub.com', 'xvideos.com', 'xhamster.com', 'redtube.com', 'xnxx.com', 'adultfriendfinder.com'];

function isAdultContent(text = '', link = ''): boolean {
  if (adultKeywords.test(text || '')) return true;
  try {
    const lower = (link || '').toLowerCase();
    if (adultDomains.some(d => lower.includes(d))) return true;
  } catch {}
  return false;
}

const defaultPlatform = (link = '') => {
  if (/youtu\.be|youtube\.com/.test(link)) return 'YouTube';
  if (/vimeo\.com/.test(link)) return 'Vimeo';
  if (/dailymotion\.com/.test(link)) return 'Dailymotion';
  if (/twitch\.tv/.test(link)) return 'Twitch';
  if (/facebook\.com/.test(link)) return 'Facebook';
  if (/instagram\.com/.test(link)) return 'Instagram';
  if (/tiktok\.com/.test(link)) return 'TikTok';
  return 'Other';
};

function inferCategory(title = '', link = ''): Category {
  const t = (title || '').toLowerCase() + ' ' + (link || '').toLowerCase();
  if (/quran|tilawat|tajweed|recitation/.test(t)) return 'Quran';
  if (/hadith|sahih|bukhari|muslim/.test(t)) return 'Hadith';
  if (/lecture|bayaan|talk|sermon|lecture|lecture series/.test(t)) return 'Lectures';
  if (/nasheed|nasheeds|nashid|hamd|naat/.test(t)) return 'Nasheeds';
  if (/music|song|mv|audio|track|album|video clip/.test(t)) return 'Music';
  if (/education|tutorial|course|how to|learn|class/.test(t)) return 'Education';
  if (/news|breaking|headlines|report|daily news/.test(t)) return 'News';
  if (/sport|football|cricket|match|game|sport highlights/.test(t)) return 'Sports';
  if (/comedy|standup|funny|sketch|meme/.test(t)) return 'Comedy';
  if (/tech|technology|programming|tutorial|developer|coding|software/.test(t)) return 'Technology';
  if (/kids|cartoon|children|kids songs|nursery/.test(t)) return 'Kids';
  if (/documentary|docu|feature|biography/.test(t)) return 'Documentary';
  if (/islam|religion|dua|azkaar|dua|tasbeeh/.test(t)) return 'Religious';
  return 'Other';
}

function makePlaceholderSVG(text: string, w = 480, h = 270) {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}' viewBox='0 0 ${w} ${h}'><rect width='100%' height='100%' fill='%23222' /><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-family='Arial, Helvetica, sans-serif' font-size='18' fill='%23ccc'>${text}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

async function fetchOEmbedData(link: string) {
  const plat = defaultPlatform(link);
  let embed = '', thumb = '', autoTitle = '';
  try {
    if (plat === 'YouTube') {
      const match = link.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/))(\w[\w-]+)/);
      const videoId = match?.[1];
      if (videoId) {
        embed = 'https://www.youtube.com/embed/' + videoId + '?rel=0&modestbranding=1';
        thumb = 'https://img.youtube.com/vi/' + videoId + '/maxresdefault.jpg';
        try {
          const res = await fetch('https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=' + videoId + '&format=json');
          const data = await res.json();
          autoTitle = data.title || '';
        } catch { }
      }
    } else if (plat === 'TikTok') {
      const videoId = link.split('/video/')[1]?.split(/[/?#]/)?.[0];
      if (videoId) embed = 'https://www.tiktok.com/embed/' + videoId;
      try { const res = await fetch('https://www.tiktok.com/oembed?url=' + encodeURIComponent(link)); const data = await res.json(); thumb = data.thumbnail_url || thumb; autoTitle = data.title || autoTitle; } catch {}
    } else if (plat === 'Vimeo') {
      const parts = link.split('/'); const videoId = parts[parts.length - 1]; embed = 'https://player.vimeo.com/video/' + videoId;
      try { const res = await fetch('https://vimeo.com/api/oembed.json?url=' + encodeURIComponent(link)); const data = await res.json(); thumb = data.thumbnail_url || thumb; autoTitle = data.title || autoTitle; } catch {}
    } else {
      embed = link;
    }
  } catch {
    embed = link;
  }

  // Fallback to inline SVG placeholder if thumb not available (avoids external DNS failures in dev)
  if (!thumb) thumb = makePlaceholderSVG(`${plat} Video`);

  return { embed, thumb, autoTitle, plat };
}

/* --------------------
   Low-bitrate preview helper (minimize spinner)
   - generates a small preview URL (mqdefault / default) for YouTube
   - falls back to provided thumbnail or SVG
   -------------------- */
function lowBitratePreviewUrl(d: { thumbnail?: string; thumbnail_url?: string; ytId?: string; baseSrc?: string }) {
  try {
    if (d.ytId) return `https://i.ytimg.com/vi/${d.ytId}/mqdefault.jpg`;
    const thumb = d.thumbnail || d.thumbnail_url || '';
    if (!thumb) return makePlaceholderSVG('Preview');
    // replace common heavy variants with a lighter one when possible
    return thumb.replace(/maxresdefault|hqdefault|sddefault/g, 'mqdefault');
  } catch { return makePlaceholderSVG('Preview'); }
}

/* --------------------
   ShortsFeed (improved mobile touch handling + minimized spinner)
   - single tap: toggle play/pause
   - double tap left/right: -5s / +5s
   - swipe up/down: prev/next (already)
   - only active item has pointer events on iframe
   - show small low-bitrate preview until iframe / YT player ready
   -------------------- */
function ShortsFeed({
  videos,
  loading,
  onDelete,
  copyLink,
  openInNewTab,
  toggleWatchLater,
  watchLater,
  subscriptions,
  toggleSubscribe,
  onGoHome,
  fullScreen = false,
  selectedCategory,
  onSelectCategory,
  jumpToId,
}: {
  videos: Video[]; loading: boolean; onDelete: (id: any) => void; copyLink: (u: string) => void; openInNewTab: (u: string) => void; toggleWatchLater: (id: any) => void; watchLater: any[]; subscriptions: string[]; toggleSubscribe: (p: string) => void; onGoHome: () => void; fullScreen?: boolean; selectedCategory?: string | null; onSelectCategory: (c: string | null) => void; jumpToId?: string | null;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [srcMap, setSrcMap] = useState<Record<string, string>>({});
  const [iframeLoaded, setIframeLoaded] = useState<Record<string, boolean>>({});
  const [userTriggeredPlay, setUserTriggeredPlay] = useState<Record<string, boolean>>({});
  const playersRef = useRef<Record<string, any>>({});
  const headerHeight = typeof window !== 'undefined' ? (document.querySelector('header') as HTMLElement)?.offsetHeight || 56 : 56;

  const visibleVideos = useMemo(() => {
    if (!selectedCategory) return videos;
    return videos.filter(v => (v.category || '').toString().trim() === selectedCategory?.toString().trim());
  }, [videos, selectedCategory]);

  const dataList = useMemo(() => visibleVideos.map((v, i) => ({ id: normalizeId(v.id) || String(i), baseSrc: v.embed_url || v.video_link || '', title: v.title, thumbnail: v.thumbnail_url, platform: v.platform, original: v, ytId: extractYouTubeId(v.embed_url || v.video_link || ''), })), [visibleVideos]);

  // Better swipe handling (keep old behavior)
  const swipeHandlers = useSwipeable({
    onSwipedUp: () => { if (activeIndex < dataList.length - 1) { const next = activeIndex + 1; (containerRef.current?.children[next] as HTMLElement)?.scrollIntoView({ behavior: 'smooth' }); } },
    onSwipedDown: () => { if (activeIndex > 0) { const prev = activeIndex - 1; (containerRef.current?.children[prev] as HTMLElement)?.scrollIntoView({ behavior: 'smooth' }); } },
    trackMouse: true, delta: 20,
  });

  useEffect(() => {
    const keep = new Set<string>();
    [activeIndex - 1, activeIndex, activeIndex + 1].forEach((i) => { if (i >= 0 && i < dataList.length) keep.add(dataList[i].id); });
    setSrcMap(prev => {
      const next: Record<string, string> = {};
      dataList.forEach((d, i) => {
        if (keep.has(d.id) && !d.ytId) {
          const shouldAutoplay = (i === activeIndex) || !!userTriggeredPlay[d.id];
          next[d.id] = resolveEmbedUrl(d.baseSrc, shouldAutoplay);
        }
      });
      return next;
    });
  }, [activeIndex, dataList, userTriggeredPlay]);

  useEffect(() => {
    let cancelled = false;
    const createPlayers = async () => {
      const needs = dataList.filter((d, i) => d.ytId && Math.abs(i - activeIndex) <= 1);
      if (needs.length === 0) return;
      try { await loadYouTubeAPI(); } catch { return; }

      needs.forEach((d) => {
        if (cancelled) return;
        if (playersRef.current[d.id]) return;
        const elId = `yt-player-${d.id}`;
        const container = document.getElementById(elId);
        if (!container) return;
        try {
          const idx = dataList.findIndex(x => x.id === d.id);
          const autoplayFlag = (idx === activeIndex) || !!userTriggeredPlay[d.id] ? 1 : 0;
          playersRef.current[d.id] = new (window as any).YT.Player(elId, {
            height: '100%', width: '100%', videoId: d.ytId,
            playerVars: { autoplay: autoplayFlag, controls: 0, modestbranding: 1, rel: 0, playsinline: 1 },
            events: {
              onReady: (e: any) => {
                // mark as loaded to remove preview placeholder
                try { setIframeLoaded(prev => ({ ...prev, [d.id]: true })); } catch {}
                const idx2 = dataList.findIndex(x => x.id === d.id);
                if (idx2 === activeIndex || userTriggeredPlay[d.id]) {
                  try { e.target.playVideo(); } catch {}
                }
              },
              onStateChange: () => {}
            }
          });
        } catch (err) {}
      });
    };
    createPlayers();
    return () => { cancelled = true; };
  }, [dataList, activeIndex, userTriggeredPlay]);

  useEffect(() => {
    Object.keys(playersRef.current).forEach((id) => {
      const player = playersRef.current[id];
      if (!player || typeof player.getPlayerState !== 'function') return;
      const idx = dataList.findIndex(d => d.id === id);
      if (idx === activeIndex) {
        try { player.playVideo(); } catch {}
      } else {
        try { player.pauseVideo?.(); } catch {}
      }
    });

    try {
      localStorage.setItem('az_shorts_index', String(activeIndex));
      if (containerRef.current) localStorage.setItem('az_shorts_scroll', String(containerRef.current.scrollTop || 0));
    } catch {}
  }, [activeIndex, dataList]);

  useEffect(() => {
    try {
      if (jumpToId) return;
      const savedIdx = parseInt(localStorage.getItem('az_shorts_index') || '0', 10);
      const savedScroll = parseInt(localStorage.getItem('az_shorts_scroll') || '0', 10);
      if (!isNaN(savedIdx) && savedIdx >= 0 && savedIdx < dataList.length) {
        setTimeout(() => {
          setActiveIndex(savedIdx);
          if (containerRef.current) containerRef.current.scrollTop = savedScroll;
        }, 80);
      }
    } catch {}
  }, []);

  useEffect(() => { if (!containerRef.current) return; (containerRef.current?.children[0] as HTMLElement)?.scrollIntoView?.({ behavior: 'smooth' }); setActiveIndex(0); }, [selectedCategory]);

  const safePostMessage = (iframe: HTMLIFrameElement, message: any) => {
    try {
      const src = iframe.src || '';
      let origin = '*';
      try { origin = new URL(src).origin; } catch { origin = '*'; }
      iframe.contentWindow?.postMessage(message, origin);
    } catch {}
  };

  const togglePlayPauseById = (vidId: string | undefined) => {
    if (!vidId) return;
    const player = playersRef.current[vidId];
    try {
      if (player && typeof player.getPlayerState === 'function') {
        const YT = (window as any).YT;
        const state = player.getPlayerState();
        if (state === YT?.PlayerState?.PLAYING) player.pauseVideo();
        else player.playVideo();
        return;
      }
    } catch {}
    try {
      const iframe = document.querySelector(`#iframe-${vidId}`) as HTMLIFrameElement | null;
      if (!iframe) return;
      const src = iframe.src || '';
      if (src.includes('autoplay=1')) {
        iframe.src = src.replace('autoplay=1', 'autoplay=0');
      } else if (src.includes('?')) {
        iframe.src = src + '&autoplay=1';
      } else {
        iframe.src = src + '?autoplay=1';
      }
    } catch {}
  };

  const seekActive = (offset: number) => {
    const d = dataList[activeIndex];
    if (!d) return;
    const p = playersRef.current[d.id];
    if (p && typeof p.getCurrentTime === 'function') {
      try { const now = p.getCurrentTime(); p.seekTo(Math.max(0, now + offset), true); } catch {}
    } else {
      const iframe = document.querySelector(`#iframe-${d.id}`) as HTMLIFrameElement | null;
      if (iframe) {
        try { safePostMessage(iframe, { event: 'seek', offset }); } catch {}
      }
    }
  };

  const gotoIndex = (i: number) => {
    if (!containerRef.current) return;
    const idx = Math.max(0, Math.min(i, dataList.length - 1));
    (containerRef.current.children[idx] as HTMLElement)?.scrollIntoView({ behavior: 'smooth' });
  };
  const gotoNext = () => { if (activeIndex < dataList.length - 1) gotoIndex(activeIndex + 1); };
  const gotoPrev = () => { if (activeIndex > 0) gotoIndex(activeIndex - 1); };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const active = document.activeElement as HTMLElement | null;
      if (active && ['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName)) return;

      const key = e.key;
      if (key === ' ' || key === 'Spacebar' || key === 'k' || key === 'K') {
        e.preventDefault();
        togglePlayPauseById(dataList[activeIndex]?.id);
      } else if (key === 'ArrowLeft' || key === 'j' || key === 'J') {
        e.preventDefault();
        seekActive(-5);
      } else if (key === 'ArrowRight' || key === 'l' || key === 'L') {
        e.preventDefault();
        seekActive(5);
      } else if (key === 'ArrowUp') {
        e.preventDefault();
        gotoPrev();
      } else if (key === 'ArrowDown') {
        e.preventDefault();
        gotoNext();
      } else if (key === 'Escape') {
        e.preventDefault();
        onGoHome();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [dataList, activeIndex]);

  const ticking = useRef(false);
  const onScroll = () => {
    if (!containerRef.current) return;
    if (ticking.current) return;
    ticking.current = true;
    requestAnimationFrame(() => {
      try {
        const children = Array.from(containerRef.current!.children) as HTMLElement[];
        const scrollTop = containerRef.current!.scrollTop;
        let closest = 0, minDiff = Infinity;
        children.forEach((c, i) => { const diff = Math.abs((c.offsetTop || 0) - scrollTop); if (diff < minDiff) { minDiff = diff; closest = i; } });
        if (closest !== activeIndex) setActiveIndex(closest);
      } catch {}
      ticking.current = false;
    });
  };

  const handleCenterClick = (vidId: string) => { togglePlayPauseById(vidId); };
  const handleLeftClick = () => { gotoPrev(); };
  const handleRightClick = () => { gotoNext(); };

  const handleLeftDoubleClick = (vidId: string) => {
    const p = playersRef.current[vidId];
    if (p && typeof p.getCurrentTime === 'function') {
      try { const now = p.getCurrentTime(); p.seekTo(Math.max(0, now - 5), true); } catch {}
    } else {
      const iframe = document.querySelector(`#iframe-${vidId}`) as HTMLIFrameElement | null;
      if (iframe) { try { safePostMessage(iframe, { event: 'seek', offset: -5 }); } catch {} }
    }
    flashIndicator('-5s');
  };
  const handleRightDoubleClick = (vidId: string) => {
    const p = playersRef.current[vidId];
    if (p && typeof p.getCurrentTime === 'function') {
      try { const now = p.getCurrentTime(); p.seekTo(now + 5, true); } catch {}
    } else {
      const iframe = document.querySelector(`#iframe-${vidId}`) as HTMLIFrameElement | null;
      if (iframe) { try { safePostMessage(iframe, { event: 'seek', offset: 5 }); } catch {} }
    }
    flashIndicator('+5s');
  };
  const handleCenterDoubleClick = (vidId: string) => {
    // double-center could be used for like/zoom; keep toggling play for now
    togglePlayPauseById(vidId);
    flashIndicator('Play');
  };

  function flashIndicator(text: string) {
    const indicator = document.createElement('div');
    indicator.textContent = text;
    indicator.style.position = 'fixed';
    indicator.style.left = '50%';
    indicator.style.top = '50%';
    indicator.style.transform = 'translate(-50%,-50%)';
    indicator.style.padding = '8px 12px';
    indicator.style.background = 'rgba(0,0,0,0.6)';
    indicator.style.color = '#fff';
    indicator.style.borderRadius = '8px';
    indicator.style.zIndex = '9999';
    document.body.appendChild(indicator);
    setTimeout(() => indicator.remove(), 650);
  }

  // Improved mobile double-tap detection (works with pointer events)
  const lastTapRef = useRef<{ time: number; tappedId?: string; timeout?: number }>({ time: 0 });
  const onPointerTap = (e: React.PointerEvent, id: string) => {
    try {
      const now = Date.now();
      const xRatio = (e.clientX || 0) / (window.innerWidth || 1);
      const last = lastTapRef.current;
      if (now - (last.time || 0) < 300 && last.tappedId === id) {
        // double tap
        if (last.timeout) { window.clearTimeout(last.timeout); last.timeout = undefined; }
        last.time = 0; last.tappedId = undefined;
        if (xRatio < 0.33) handleLeftDoubleClick(id);
        else if (xRatio > 0.66) handleRightDoubleClick(id);
        else handleCenterDoubleClick(id);
        return;
      }

      // schedule single-tap action (cancelled if double-tap)
      last.time = now; last.tappedId = id;
      if (last.timeout) window.clearTimeout(last.timeout);
      last.timeout = window.setTimeout(() => {
        // single tap
        handleCenterClick(id);
        last.time = 0; last.tappedId = undefined; last.timeout = undefined;
      }, 260) as unknown as number;
    } catch {}
  };

  // forward global key events to shorts (used by desktop too)
  useEffect(() => {
    const handler = (ev: Event) => {
      try {
        const detail = (ev as CustomEvent).detail;
        if (!detail) return;
        const key = detail.key;
        if (key === ' ' || key === 'Spacebar' || key === 'k' || key === 'K') togglePlayPauseById(dataList[activeIndex]?.id);
        if (key === 'ArrowLeft' || key === 'j' || key === 'J') seekActive(-5);
        if (key === 'ArrowRight' || key === 'l' || key === 'L') seekActive(5);
        if (key === 'ArrowUp') gotoPrev();
        if (key === 'ArrowDown') gotoNext();
      } catch {}
    };
    window.addEventListener('az_shorts_key', handler as EventListener);
    return () => window.removeEventListener('az_shorts_key', handler as EventListener);
  }, [dataList, activeIndex]);

  return (
    <div className={`${fullScreen ? 'fixed inset-0 z-[90]' : 'relative'} bg-black text-white`} role="region" aria-label="Shorts feed">
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-[95] w-[96%] max-w-[1200px] pointer-events-auto">
        <div className="flex items-center justify-between gap-3 bg-black/40 backdrop-blur-md rounded-full px-3 py-2 shadow-md">
          <div className="flex items-center gap-3">
            <button onClick={onGoHome} className="flex items-center gap-2" style={{ background: `linear-gradient(90deg, ${BRAND.primaryFrom}, ${BRAND.primaryTo})`, color: '#fff', padding: '8px 14px', borderRadius: 999, fontWeight: 700 }} aria-label="Go home">🏠 Home</button>
            <div className="hidden md:flex items-center ml-2"><CategoriesBar categories={ALL_CATEGORIES} selected={selectedCategory ?? null} onSelect={onSelectCategory} compact /></div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-xs text-white/80 mr-1 hidden sm:block">Swipe up / down</div>
            <button onClick={() => containerRef.current && containerRef.current.scrollTo({ top: 0, behavior: 'smooth' })} className="bg-black/30 px-3 py-1 rounded-full text-sm">Top</button>
          </div>
        </div>
        <div className="mt-2 block md:hidden"><CategoriesBar categories={ALL_CATEGORIES} selected={selectedCategory ?? null} onSelect={onSelectCategory} compact /></div>
      </div>

      {loading && <div className="absolute inset-0 flex items-center justify-center z-[90]"><div className="w-16 h-16 bg-gray-800 animate-pulse rounded-lg" /></div>}

      <div {...swipeHandlers} ref={containerRef as any} onScroll={onScroll}
           className="shorts-container w-full"
           style={{ height: `calc(100vh - ${headerHeight}px)`, WebkitOverflowScrolling: 'touch', touchAction: 'pan-y' }}>
        {dataList.length === 0 && (<div className="h-full w-full flex items-center justify-center text-gray-400">No videos in this category</div>)}

        {dataList.map((d, i) => {
          const id = d.id;
          const src = srcMap[id] || '';
          const isActive = i === activeIndex;
          const previewSrc = lowBitratePreviewUrl({ thumbnail: d.thumbnail, thumbnail_url: d.thumbnail, ytId: d.ytId, baseSrc: d.baseSrc });

          return (
            <div key={id} className="shorts-item snap-start snap-stop-always w-full relative flex items-center justify-center bg-black" style={{ minHeight: `calc(100vh - ${headerHeight}px - env(safe-area-inset-bottom, 56px))` }}>
              {(!d.ytId && !src) && (<img src={d.thumbnail || makePlaceholderSVG('Video')} alt={d.title} className="w-full h-full object-cover" loading="lazy" />)}

              {d.ytId ? (
                <div id={`yt-player-${id}`} className="w-full h-full absolute inset-0" />
              ) : (
                <>
                  {/* preview layer shown until iframe reports loaded */}
                  {!iframeLoaded[id] && (
                    <div className="absolute inset-0 z-20 flex items-center justify-center">
                      <img src={previewSrc} alt={d.title || 'preview'} className="w-full h-full object-cover blur-sm scale-[1.03]" loading="lazy" />
                      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg, rgba(0,0,0,0.15), rgba(0,0,0,0.25))' }} />
                    </div>
                  )}

                  <iframe
                    id={`iframe-${id}`}
                    src={src}
                    title={d.title || `video-${i}`}
                    className="w-full h-full block absolute inset-0"
                    frameBorder="0"
                    allow="autoplay; fullscreen; picture-in-picture; encrypted-media; accelerometer"
                    style={{ pointerEvents: isActive ? 'auto' : 'none', opacity: iframeLoaded[id] ? 1 : 0, transition: 'opacity 220ms ease-in-out' }}
                    loading="lazy"
                    onLoad={() => { try { setIframeLoaded(prev => ({ ...prev, [id]: true })); } catch {} }}
                  />
                </>
              )}

              {/* Interaction layer: capture pointer events and implement single/double tap and side taps */}
              <div
                onPointerDown={(e) => onPointerTap(e, id)}
                role="button"
                aria-label={`Video controls for ${d.title || 'video'}`}
                className="absolute inset-0 z-30"
                style={{ touchAction: 'manipulation' }}
              />

              <div className="absolute top-4 right-4 z-50 flex flex-col gap-2">
                <button onClick={() => copyLink(d.baseSrc || src)} className="bg-black/40 text-white px-3 py-1 rounded-full text-xs">Copy</button>
                <button onClick={() => toggleWatchLater(d.original.id)} className="bg-black/40 text-white px-3 py-1 rounded-full text-xs" aria-pressed={watchLater.includes(d.original.id)}>{watchLater.includes(d.original.id) ? 'Saved' : 'Watch'}</button>
                <button onClick={() => toggleSubscribe(String(d.original.platform || ''))} className="bg-black/40 text-white px-3 py-1 rounded-full text-xs" aria-pressed={subscriptions.includes(String(d.original.platform || ''))}>{subscriptions.includes(String(d.original.platform || '')) ? 'Unsub' : 'Sub'}</button>
                <button onClick={() => openInNewTab(d.baseSrc || src)} className="bg-black/40 text-white px-3 py-1 rounded-full text-xs">Open</button>
                <button onClick={() => onDelete(d.original.id)} className="bg-black/40 text-red-400 px-3 py-1 rounded-full text-xs">Delete</button>
              </div>

              <div className="absolute left-4 bottom-6 z-50 max-w-[70%]">
                <h3 className="text-white font-semibold text-lg line-clamp-2">{d.title}</h3>
                <p className="text-xs text-white/70 mt-1">{d.platform || '—'}</p>
              </div>
            </div>
          );
        })}
      </div>

      <AnimatePresence>
        <motion.button initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }} whileTap={{ scale: 0.95 }} onClick={() => { try { const el = document.querySelector('.shorts-scroll-anchor') as HTMLElement | null; if (el) el.scrollIntoView({ behavior: 'smooth' }); } catch {} }} aria-label="Open Shorts" className="fixed z-[60] right-6 bottom-6 md:right-10 md:bottom-10 flex items-center justify-center rounded-full shadow-xl" style={{ width: 68, height: 68, background: `linear-gradient(90deg, ${BRAND.accentFrom}, ${BRAND.accentTo})`, color: '#fff' }}>
          <IconShorts />
        </motion.button>
      </AnimatePresence>
    </div>
  );
}

/* --------------------
   TopCarousel (unchanged)
   -------------------- */
const TopCarousel = React.memo(function TopCarousel({ videos, onCopy, onOpen, onSelect }: { videos: Video[]; onCopy: (u: string) => void; onOpen: (u: string) => void; onSelect: (v: Video) => void; }) {
  if (!videos || videos.length === 0) return null;
  return (
    <div className="mb-4">
      <div className="flex gap-4 overflow-x-auto py-3 px-3">
        {videos.map((v) => (
          <motion.div key={normalizeId(v.id)} whileHover={{ scale: 1.03 }} className="min-w-[160px] sm:min-w-[220px] bg-gradient-to-b from-gray-900 to-gray-800 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer" onClick={() => onSelect(v)}>
            <img src={v.thumbnail_url || makePlaceholderSVG('Video')} alt={v.title} className="w-full h-36 object-cover" loading="lazy" />
            <div className="p-3">
              <div className="text-sm text-gray-200 line-clamp-2">{v.title}</div>
              <div className="mt-2 flex gap-2 justify-end">
                <button onClick={(e) => { e.stopPropagation(); onCopy(v.video_link || v.embed_url || ''); }} className="text-xs px-2 py-1 rounded bg-white/5">Copy</button>
                <button onClick={(e) => { e.stopPropagation(); onOpen(v.video_link || v.embed_url || ''); }} className="text-xs px-2 py-1 rounded bg-white/5">Open</button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
});

/* --------------------
   WatchPage (unchanged)
   -------------------- */
function WatchPage({ video, suggestions, onOpenInNewTab, onCopy, onSelect }: { video: Video; suggestions: Video[]; onOpenInNewTab: (u: string) => void; onCopy: (u: string) => void; onSelect: (v: Video) => void; }) {
  const embed = resolveEmbedUrl(video.embed_url || video.video_link || '', true);
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'VideoObject',
    name: video.title || '',
    description: video.title || '',
    thumbnailUrl: video.thumbnail_url || '',
    uploadDate: video.created_at || new Date().toISOString(),
    contentUrl: video.video_link || embed || '',
    embedUrl: embed || ''
  } as any;

  return (
    <div className="min-h-screen bg-black text-white pb-8">
      <div className="max-w-[1100px] mx-auto px-4 py-6">
        <div className="bg-black rounded-xl overflow-hidden mb-4 shadow-lg">
          <iframe className="w-full h-[56vw] sm:h-[50vh]" src={embed} title={video.title} frameBorder="0" allow="autoplay; fullscreen; picture-in-picture" />
        </div>

        <div className="flex flex-col sm:flex-row items-start justify-between gap-4 mb-6">
          <div className="flex-1">
            <h1 className="text-lg sm:text-xl font-semibold">{video.title}</h1>
            <p className="text-xs text-gray-400 mt-1">{video.platform} • {video.category || '—'}</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => onCopy(video.video_link || embed)} className="px-3 py-1 rounded border text-sm">Copy</button>
            <button onClick={() => onOpenInNewTab(video.video_link || embed)} className="px-3 py-1 rounded border text-sm">Open</button>
          </div>
        </div>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

        <h3 className="text-sm text-gray-300 mb-3">More from AzkaarTube</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {suggestions.map((v) => (
            <motion.article key={normalizeId(v.id)} whileHover={{ scale: 1.02 }} className="bg-gray-900 rounded-xl overflow-hidden cursor-pointer" onClick={() => onSelect(v)}>
              <img src={v.thumbnail_url || makePlaceholderSVG('Video')} alt={v.title} className="w-full h-28 object-cover" loading="lazy" />
              <div className="p-2">
                <div className="text-sm font-medium line-clamp-2">{v.title}</div>
                <div className="text-xs text-gray-400 mt-1">{v.platform}</div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </div>
  );
}

/* --------------------
   Inline AddVideoForm (unchanged)
   -------------------- */
function AddVideoForm({ onCancel, onAdded }: { onCancel: () => void; onAdded?: (v: Video) => void }) {
  const [title, setTitle] = useState('');
  const [videoLink, setVideoLink] = useState('');
  const [embedUrl, setEmbedUrl] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [platform, setPlatform] = useState('');
  const [category, setCategory] = useState<Category>('Other');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!videoLink) return;
    let mounted = true;
    (async () => {
      const data = await fetchOEmbedData(videoLink);
      if (!mounted) return;
      setEmbedUrl(data.embed);
      setThumbnailUrl(data.thumb);
      setPlatform(data.plat);
      const autoCat = inferCategory(data.autoTitle || '', videoLink);
      setCategory(autoCat);
      if (!title && data.autoTitle) setTitle(data.autoTitle);
    })();
    return () => { mounted = false; };
  }, [videoLink]);

  const addVideo = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!videoLink) return alert('Video link is required');
    if (isAdultContent(title, videoLink)) { alert('Upload blocked: adult / explicit content is not allowed.'); return; }

    setLoading(true);
    try {
      const payload = { title: title || videoLink, video_link: videoLink, embed_url: embedUrl || videoLink, thumbnail_url: thumbnailUrl || '', platform, category };
      const { data, error } = await supabase.from('videos').insert([payload]).select();
      if (error) throw error;
      if (data && data.length) {
        const newItem = data[0] as Video;
        onAdded?.(newItem);
        setTitle(''); setVideoLink(''); setEmbedUrl(''); setThumbnailUrl(''); setPlatform(''); setCategory('Other');
      }
    } catch (err: any) { console.error('addVideo error', err); alert(err?.message || 'Failed to add video'); }
    finally { setLoading(false); }
  };

  return (
    <div className="w-full rounded-2xl p-4 shadow-md bg-gray-900">
      <form onSubmit={addVideo} className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-start">
        <div className="sm:col-span-2 space-y-2">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Video title (optional)" className="w-full p-2 rounded-lg border border-gray-700 bg-gray-900 text-sm text-white" />
          <input value={videoLink} onChange={(e) => setVideoLink(e.target.value)} placeholder="Video link (paste YouTube, TikTok, Vimeo...)" className="w-full p-2 rounded-lg border border-gray-700 bg-gray-900 text-sm text-white" />
          <div className="flex items-center gap-2">
            {thumbnailUrl ? (
              <img src={thumbnailUrl || makePlaceholderSVG('Preview')} alt="thumbnail" loading="lazy" className="w-36 h-20 object-cover rounded-lg" />
            ) : (
              <div className="w-36 h-20 bg-gray-800 rounded-lg flex items-center justify-center text-xs text-gray-400">Preview</div>
            )}
            <div className="text-xs text-gray-400">Detected: <span className="font-medium">{platform || '—'}</span></div>
          </div>
          <div className="text-xs text-red-600">Note: Uploads containing adult/explicit content will be blocked automatically.</div>
        </div>

        <div className="sm:col-span-1 flex flex-col gap-2">
          <select value={category} onChange={(e) => setCategory(e.target.value as Category)} className="w-full p-2 rounded-lg border border-gray-700 bg-gray-900 text-sm text-white">
            {ALL_CATEGORIES.map(c => <option key={c} className="bg-gray-900 text-white">{c}</option>)}
          </select>
          <div className="flex flex-col gap-2">
            <button type="submit" className="w-full px-3 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm" disabled={loading}>{loading ? 'Adding...' : 'Add video'}</button>
            <button type="button" onClick={() => { setTitle(''); setVideoLink(''); setEmbedUrl(''); setThumbnailUrl(''); setPlatform(''); setCategory('Other'); }} className="w-full px-3 py-2 rounded-lg border border-gray-700 text-sm">Reset</button>
          </div>
          <button type="button" onClick={onCancel} className="mt-2 px-3 py-1 rounded bg-gray-700 text-sm">Cancel</button>
        </div>
      </form>
    </div>
  );
}

/* --------------------
   Main Page (glue + full-site keyboard)
   - minor production-friendly fixes applied
   - spinner minimized: preview placeholders + iframe onLoad + YT onReady set loaded flag
   -------------------- */
export default function Page(): JSX.Element {
  const [videos, setVideos] = useLocalStorage<Video[]>('az_videos', []);
  const [jumpToId, setJumpToId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [mobileTab, setMobileTab] = useState<'home' | 'add' | 'shorts' | 'library' | 'profile'>('home');
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [theme, setTheme] = useLocalStorage<'dark' | 'light'>('az_theme', 'dark');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const [subscriptions, setSubscriptions] = useLocalStorage<string[]>('az_subs', []);
  const [watchLater, setWatchLater] = useLocalStorage<string[]>('az_watchlater', []);

  const fetchVideosFromSupabase = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.from('videos').select('*').order('created_at', { ascending: false }).limit(500);
      if (error) throw error;
      if (data) {
        setVideos(prev => {
          const map = new Map<string, Video>();
          (data as Video[]).forEach(v => map.set(normalizeId(v.id), v));
          (prev || []).forEach(v => { if (!map.has(normalizeId(v.id))) map.set(normalizeId(v.id), v); });
          return Array.from(map.values());
        });
      }
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, [setVideos]);

  useEffect(() => { fetchVideosFromSupabase(); }, [fetchVideosFromSupabase]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    document.body.style.background = '#000';
    document.body.style.margin = '0';
    document.body.style.minHeight = '100vh';
  }, [theme]);

  const filtered = useMemo(() => {
    let list = videos || [];
    if (selectedCategory) list = list.filter(v => (v.category || '').toString().trim() === selectedCategory.trim());
    const q = searchQuery.trim().toLowerCase();
    if (q) list = list.filter(v => (v.title || '').toLowerCase().includes(q) || (v.platform || '').toLowerCase().includes(q));
    return list;
  }, [videos, searchQuery, selectedCategory]);

  const topCarousel = filtered.slice(0, 8);

  useEffect(() => {
    if (mobileTab === 'shorts') {
      const hosts = ['https://www.youtube.com', 'https://player.vimeo.com', 'https://www.tiktok.com'];
      hosts.forEach(h => { if (!document.querySelector(`link[rel="preconnect"][href="${h}"]`)) { const l = document.createElement('link'); l.rel = 'preconnect'; l.href = h; l.crossOrigin = ''; document.head.appendChild(l); } });
    }
  }, [mobileTab]);

  // Auto-detect mobile vs desktop on first client render and open Shorts on mobile
  useEffect(() => {
    try {
      const ua = navigator.userAgent || '';
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua) || (window.innerWidth && window.innerWidth <= 800);
      if (isMobile) setMobileTab('shorts'); else setMobileTab('home');
    } catch (err) {
      // fallback keep default
    }
    // run only once on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Full-site keyboard handling (global)
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const active = document.activeElement as HTMLElement | null;
      if (active && ['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName)) return;

      if (e.key === 'Escape') {
        if (showAddModal) {
          e.preventDefault();
          setShowAddModal(false);
          return;
        }
        if (selectedVideo) {
          e.preventDefault();
          setSelectedVideo(null);
          return;
        }
        if (mobileTab === 'shorts') {
          e.preventDefault();
          setMobileTab('home');
          return;
        }
      }

      if (e.key === 's' || e.key === 'S') { e.preventDefault(); setMobileTab('shorts'); return; }
      if (e.key === 'h' || e.key === 'H') { e.preventDefault(); setMobileTab('home'); return; }
      if (e.key === 'a' || e.key === 'A') { e.preventDefault(); setShowAddModal(true); return; }
      if (e.key === '/') { e.preventDefault(); const q = document.querySelector('input[placeholder*="Search"]') as HTMLInputElement | null; q?.focus(); return; }

      if (/^[1-9]$/.test(e.key)) {
        const idx = parseInt(e.key, 10) - 1;
        if (filtered && filtered[idx]) { e.preventDefault(); setSelectedVideo(filtered[idx]); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
      }

      if (mobileTab === 'shorts') {
        const keysToForward = [' ', 'Spacebar', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'k', 'K', 'j', 'J', 'l', 'L', 'Escape'];
        if (keysToForward.includes(e.key)) {
          try { window.dispatchEvent(new CustomEvent('az_shorts_key', { detail: { key: e.key } })); e.preventDefault(); } catch {}
        }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [filtered, mobileTab, showAddModal, selectedVideo]);

  const openWatchSameTab = (v: Video) => {
    setSelectedVideo(v);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    try { const url = new URL(window.location.href); url.searchParams.set('watch', String(v.id)); window.history.pushState({}, '', url.toString()); } catch {}
  };

  const copyLink = async (u: string) => { try { await navigator.clipboard.writeText(u); } catch {} };
  const openInNewTab = (u: string) => { try { window.open(u, '_blank', 'noopener'); } catch {} };
  const toggleWatchLater = (id: any) => setWatchLater(prev => prev.includes(id) ? prev.filter(x => x !== id) : [id, ...prev]);
  const toggleSubscribe = (p: string) => setSubscriptions(prev => prev.includes(p) ? prev.filter(x => x !== p) : [p, ...prev]);
  const deleteVideo = async (id: any) => { if (!confirm('Delete this video?')) return; try { const { error } = await supabase.from('videos').delete().eq('id', id); if (error) throw error; setVideos(prev => (prev || []).filter(v => normalizeId(v.id) !== normalizeId(id))); if (selectedVideo?.id === id) setSelectedVideo(null); } catch (err) { alert('Delete failed'); } };

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const watch = params.get('watch');
      if (watch && videos.length) {
        const found = videos.find(v => normalizeId(v.id) === normalizeId(watch) || v.video_link === watch || v.embed_url === watch);
        if (found) setSelectedVideo(found);
      }
    } catch {}
  }, [videos]);

  useEffect(() => { if (mobileTab !== 'shorts') setJumpToId(null); }, [mobileTab]);

  const saveHomeScroll = () => { try { localStorage.setItem('az_home_scroll', String(window.scrollY || 0)); } catch {} };
  const restoreHomeScroll = () => { try { const s = parseInt(localStorage.getItem('az_home_scroll') || '0', 10); if (!isNaN(s)) window.scrollTo({ top: s, behavior: 'auto' }); } catch {} };

  const goToShorts = () => {
    try {
      saveHomeScroll();
      if (selectedVideo) {
        try { setJumpToId(normalizeId(selectedVideo.id)); } catch {}
        setSelectedVideo(null);
      }
      setMobileTab('shorts');
    } catch (err) { setMobileTab('shorts'); }
  };
  const goToHome = () => { setMobileTab('home'); setSelectedCategory(null); setTimeout(() => { restoreHomeScroll(); }, 50); };

  const openAddModal = () => { setShowAddModal(true); };
  const closeAddModal = () => {
    setShowAddModal(false);
    try {
      const url = new URL(window.location.href);
      if (url.searchParams.has('add')) {
        url.searchParams.delete('add');
        window.history.replaceState({}, '', url.toString());
      }
    } catch {}
  };

  const azVariants = useMemo(() => {
    const lower = 'azkaartube'.toLowerCase();
    const vset = new Set<string>();
    ['Azkaartube','azkaartube','AzkaarTube','azkaar tube','azkaar-tube'].forEach(x => vset.add(x));
    return Array.from(vset).slice(0, 40);
  }, []);

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://example.com'; // replace with your site URL for Search Console

  return (
    <div className="min-h-screen bg-black text-white">
      <Head>
        <title>Azkaartube — Short Videos & Lectures</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="Azkaartube — Islamic short videos, lectures, nasheeds and more. Watch, share and discover Azkaartube content." />
        <meta name="keywords" content={azVariants.join(', ')} />
        <meta name="application-name" content="Azkaartube" />
        <link rel="canonical" href={`${siteUrl}/`} />

        {/* Open Graph / Twitter to help brand detection */}
        <meta property="og:site_name" content="Azkaartube" />
        <meta property="og:title" content="Azkaartube — Short Videos & Lectures" />
        <meta property="og:description" content="Islamic short videos, lectures & nasheeds — Azkaartube." />
        <meta property="og:url" content={`${siteUrl}/`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Azkaartube — Short Videos & Lectures" />

        {/* Organization & WebSite schema to help Search Console detect the brand */}
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          "name": "Azkaartube",
          "url": siteUrl,
          "potentialAction": {
            "@type": "SearchAction",
            "target": `${siteUrl}/?s={search_term_string}`,
            "query-input": "required name=search_term_string"
          }
        }) }} />

        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "Azkaartube",
          "url": siteUrl,
          "alternateName": ["Azkaartube","AzkaarTube","azkaartube","azkaar tube"],
          "logo": `${siteUrl}/logo.png`,
          "sameAs": []
        }) }} />
      </Head>

      <style>{`
        :root { --container: 1200px; --primary-from: ${BRAND.primaryFrom}; --primary-to: ${BRAND.primaryTo}; --accent-from: ${BRAND.accentFrom}; --accent-to: ${BRAND.accentTo}; }
        html, body, #__next { height: 100%; margin: 0; padding: 0; }
        body { background: #000; }
        iframe { display: block; border: 0; }
        .safe-bottom { padding-bottom: env(safe-area-inset-bottom, 16px); }
        .line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .shorts-container { overflow-y: auto; scroll-snap-type: y mandatory; -webkit-overflow-scrolling: touch; overscroll-behavior-y: contain; }
        .shorts-item { scroll-snap-align: start; scroll-snap-stop: always; }
        .home-min-height { min-height: calc(100vh - 56px - env(safe-area-inset-bottom, 56px)); }
        button, input, select { touch-action: manipulation; }
        .mobile-detect-h1 { display: none; }
        @media (max-width: 767px) {
          .mobile-detect-h1 { display: block; font-size: 18px; font-weight: 700; margin-top: 8px; margin-bottom: 10px; }
        }
      `}</style>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-transparent backdrop-blur-sm" role="banner">
        <div className="max-w-[1200px] mx-auto px-4 py-3 flex items-center gap-4 h-14">
          <div className="flex items-center gap-3">
            <a href="/" className="flex items-center gap-3" aria-label="Azkaartube home">
              <div className="w-9 h-9 rounded-full" style={{ background: `linear-gradient(90deg, ${BRAND.accentFrom}, ${BRAND.accentTo})` }}>
                <div className="w-full h-full rounded-full flex items-center justify-center text-white font-bold shadow">A</div>
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-sm font-semibold">Azkaartube</span>
                <span className="text-[11px] text-gray-400 -mt-0.5">Shorts & Lectures</span>
              </div>
            </a>
          </div>

          <div className="flex-1 px-3">
            <div className="relative max-w-[900px] mx-auto">
              <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search videos, titles or tags" className="w-full rounded-full border border-gray-800 bg-black/60 text-sm px-4 py-2 focus:outline-none text-white shadow-inner" />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="p-2 rounded-md bg-gray-800/50" aria-label="Toggle theme">{theme === 'dark' ? '☀️' : '🌙'}</button>
            <button onClick={() => goToShorts()} className={`px-3 py-1 rounded-full text-white text-sm hidden md:inline`} style={{ background: `linear-gradient(90deg, ${BRAND.primaryFrom}, ${BRAND.primaryTo})` }}>Shorts</button>

            <button onClick={() => { fetchVideosFromSupabase(); setMobileTab('home'); setSelectedCategory(null); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="px-3 py-1 rounded-full bg-gray-800 text-white text-sm">Refresh Home</button>

            <button onClick={() => openAddModal()} className="px-3 py-1 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 text-white text-sm hidden md:inline ml-2">Add</button>
          </div>
        </div>

        <div className="max-w-[1200px] mx-auto px-4 pb-3"><CategoriesBar categories={ALL_CATEGORIES} selected={selectedCategory} onSelect={(c) => setSelectedCategory(c)} /></div>

        <div className="max-w-[1400px] mx-auto px-4">
          <h1 className="mobile-detect-h1">Azkaartube — Shorts, Lectures & Nasheeds</h1>
        </div>
      </header>

      <main className={`pt-14 pb-24 max-w-[1400px] mx-auto px-4 safe-bottom ${mobileTab==='home' && !selectedVideo ? 'home-min-height' : ''}`}>
        {!selectedVideo && mobileTab === 'home' && (
          <h1 className="text-2xl font-bold mt-2 mb-3">Azkaartube — Islamic shorts, lectures & nasheeds</h1>
        )}

        {selectedVideo ? (
          <WatchPage video={selectedVideo} suggestions={filtered.filter(v => normalizeId(v.id) !== normalizeId(selectedVideo.id)).slice(0, 12)} onOpenInNewTab={(u) => openInNewTab(u)} onCopy={(u) => copyLink(u)} onSelect={(v) => openWatchSameTab(v)} />
        ) : (
          <>
            {mobileTab === 'shorts' ? (
              <ShortsFeed videos={filtered} loading={loading} onDelete={deleteVideo} copyLink={copyLink} openInNewTab={openInNewTab} toggleWatchLater={toggleWatchLater} watchLater={watchLater} subscriptions={subscriptions} toggleSubscribe={toggleSubscribe} onGoHome={() => { goToHome(); }} fullScreen={true} selectedCategory={selectedCategory} onSelectCategory={(c) => setSelectedCategory(c)} jumpToId={jumpToId} />
            ) : (
              <>
                <TopCarousel videos={topCarousel} onCopy={copyLink} onOpen={openInNewTab} onSelect={(v) => { openWatchSameTab(v); }} />
                <div className="grid gap-4 sm:gap-5 md:gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 px-2">
                  {filtered.map((video) => (
                    <motion.article key={normalizeId(video.id)} whileHover={{ scale: 1.03 }} className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-2xl overflow-hidden shadow-lg cursor-pointer transform transition-transform" onClick={() => openWatchSameTab(video)}>
                      <img src={video.thumbnail_url || makePlaceholderSVG('Video')} alt={video.title} className="w-full h-36 object-cover" loading="lazy" />
                      <div className="p-3 flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <h3 className="font-medium text-sm line-clamp-2 text-white">{video.title}</h3>
                          <div className="text-xs text-gray-400 mt-1">{video.platform} • {video.category || '—'}</div>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <button onClick={(e) => { e.stopPropagation(); copyLink(video.video_link || video.embed_url || ''); }} className="text-xs text-gray-300">Copy</button>
                          <button onClick={(e) => { e.stopPropagation(); openInNewTab(video.video_link || video.embed_url || ''); }} className="text-xs text-gray-300">Open</button>
                        </div>
                      </div>
                    </motion.article>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </main>

      <AnimatePresence>
        <motion.button initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }} whileTap={{ scale: 0.96 }} onClick={() => goToShorts()} className="fixed z-[60] right-6 bottom-6 md:right-10 md:bottom-10 flex items-center justify-center rounded-full shadow-xl" style={{ width: 64, height: 64, background: `linear-gradient(90deg, ${BRAND.accentFrom}, ${BRAND.accentTo})`, color: '#fff' }} aria-label="Open shorts">
          <IconShorts />
        </motion.button>
      </AnimatePresence>

      <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-black/95 border-t border-gray-800" role="navigation" aria-label="Mobile bottom navigation">
        <div className="max-w-[1200px] mx-auto flex justify-between px-4 py-2 items-center safe-bottom">
          <button className={`flex-1 flex flex-col items-center justify-center py-1 text-xs ${mobileTab==='home'?'text-white':'text-gray-400'}`} onClick={() => { goToHome(); }} aria-current={mobileTab==='home'}>🏠<span className="text-xs">Home</span></button>

          <button onClick={() => openAddModal()} className="-mt-6 bg-gradient-to-tr from-pink-500 to-orange-400 rounded-full w-14 h-14 flex items-center justify-center shadow-xl text-white text-2xl" aria-label="Add video">+</button>

          <button className={`flex-1 flex flex-col items-center justify-center py-1 text-xs ${mobileTab==='shorts'?'text-white':'text-gray-400'}`} onClick={() => { goToShorts(); }} aria-current={mobileTab==='shorts'}>{'🎬'}<span className="text-xs">Shorts</span></button>
        </div>
      </nav>

      <AnimatePresence>
        {showAddModal && (
          <motion.div
            key="add-modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60"
            onClick={() => { closeAddModal(); }}
          >
            <motion.div
              initial={{ scale: 0.98 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.98 }}
              className="w-[92%] max-w-[720px] bg-gray-900 rounded-xl p-4 relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => { closeAddModal(); }}
                aria-label="Close add video"
                className="absolute top-3 right-3 z-50 w-9 h-9 rounded-full bg-gray-800/60 flex items-center justify-center text-white"
                title="Close"
              >
                ✖
              </button>

              <h3 className="text-lg font-semibold mb-3">Add Video</h3>
              <AddVideoForm
                onCancel={closeAddModal}
                onAdded={(newVideo: any) => {
                  try { setVideos(prev => [newVideo, ...(prev || [])]); } catch {}
                  closeAddModal();
                }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
