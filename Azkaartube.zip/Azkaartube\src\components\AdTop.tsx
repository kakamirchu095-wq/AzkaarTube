'use client';
import { useEffect } from 'react';

export default function AdTop() {
  const client = process.env.NEXT_PUBLIC_ADSENSE_ID;
  const slot = process.env.NEXT_PUBLIC_ADSENSE_SLOT_TOP;
  useEffect(() => {
    try { (window as any).adsbygoogle = (window as any).adsbygoogle || []; (window as any).adsbygoogle.push({}); } catch {}
  }, []);
  if (!client || !slot) return null;
  return (
    <ins className="adsbygoogle block w-full"
      style={{ display: 'block' }}
      data-ad-client={client}
      data-ad-slot={slot}
      data-ad-format="auto"
      data-full-width-responsive="true"
    />
  );
}
