import { NextResponse } from 'next/server';

function ytId(u: URL) {
  if (u.hostname.includes('youtu.be')) return u.pathname.slice(1);
  if (u.searchParams.get('v')) return u.searchParams.get('v');
  const m = u.pathname.match(/\/shorts\/([^/]+)/) || u.pathname.match(/\/embed\/([^/]+)/);
  return m ? m[1] : null;
}

async function fetchJson(url: string) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('Provider error');
  return res.json();
}

function isoDurationToSeconds(iso: string) {
  // Simple parse for PT#H#M#S
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!m) return null;
  const h = parseInt(m[1]||"0"), mm = parseInt(m[2]||"0"), s = parseInt(m[3]||"0");
  return h*3600 + mm*60 + s;
}

function formatDuration(seconds: number|null) {
  if (seconds === null) return null;
  const h = Math.floor(seconds/3600); seconds%=3600;
  const m = Math.floor(seconds/60); const s = seconds%60;
  if (h>0) return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return `${m}:${String(s).padStart(2,'0')}`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { url } = body || {};
    if (!url) return NextResponse.json({ error: 'Missing url' }, { status: 400 });
    const u = new URL(url);

    let parsed;
    // YouTube - prefer YouTube Data API if key present
    if (u.hostname.includes('youtu')) {
      const id = ytId(u);
      if (!id) throw new Error('Invalid YouTube URL');
      const apiKey = process.env.YOUTUBE_API_KEY || process.env.NEXT_PUBLIC_YOUTUBE_API_KEY;
      if (apiKey) {
        // Fetch via YouTube Data API v3
        try {
          const apiUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=${encodeURIComponent(id)}&key=${apiKey}`;
          const j = await fetchJson(apiUrl);
          const item = j.items?.[0];
          const snippet = item?.snippet;
          const content = item?.contentDetails;
          const seconds = content?.duration ? isoDurationToSeconds(content.duration) : null;
          // Prefer maxres thumbnail, fallback to hqdefault
          const thumb = snippet?.thumbnails?.maxres?.url || snippet?.thumbnails?.high?.url || `https://img.youtube.com/vi/${id}/hqdefault.jpg`;
          parsed = {
            provider: 'youtube',
            embed_url: `https://www.youtube.com/embed/${id}`,
            thumb_url: thumb,
            title: snippet?.title ?? `YouTube Video ${id}`,
            description: snippet?.description ?? null,
            duration: formatDuration(seconds),
            meta: item ?? null
          };
        } catch (e) {
          // fallback to simple approach
          parsed = {
            provider: 'youtube',
            embed_url: `https://www.youtube.com/embed/${id}`,
            thumb_url: `https://img.youtube.com/vi/${id}/hqdefault.jpg`,
            title: `YouTube Video ${id}`
          };
        }
      } else {
        // no API key, fallback to basic thumbnail and embed
        parsed = {
          provider: 'youtube',
          embed_url: `https://www.youtube.com/embed/${id}`,
          thumb_url: `https://img.youtube.com/vi/${id}/hqdefault.jpg`,
          title: `YouTube Video ${id}`
        };
      }
    } else if (u.hostname.includes('vimeo')) {
      const j = await fetchJson(`https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`);
      parsed = {
        provider: 'vimeo',
        embed_url: j?.html?.match(/src="([^"]+)"/)?.[1] ?? url,
        thumb_url: j?.thumbnail_url ?? null,
        title: j?.title ?? 'Vimeo Video'
      };
    } else if (u.hostname.includes('dailymotion') || u.hostname.includes('dai.ly')) {
      const j = await fetchJson(`https://www.dailymotion.com/services/oembed?url=${encodeURIComponent(url)}`);
      parsed = {
        provider: 'dailymotion',
        embed_url: j?.html?.match(/src="([^"]+)"/)?.[1] ?? url,
        thumb_url: j?.thumbnail_url ?? null,
        title: j?.title ?? 'Dailymotion Video'
      };
    } else if (u.hostname.includes('facebook.com') || u.hostname.includes('fb.watch')) {
      const embed_url = `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}&show_text=false&width=1280`;
      let thumb_url = null;
      const token = process.env.FACEBOOK_APP_TOKEN;
      if (token) {
        try {
          const j = await fetchJson(`https://graph.facebook.com/v19.0/oembed_video?url=${encodeURIComponent(url)}&access_token=${token}`);
          thumb_url = j?.thumbnail_url ?? null;
        } catch {}
      }
      parsed = { provider: 'facebook', embed_url, thumb_url, title: 'Facebook Video' };
    } else {
      try {
        const j = await fetchJson(`https://noembed.com/embed?url=${encodeURIComponent(url)}`);
        parsed = {
          provider: (j?.provider_name || 'generic').toLowerCase(),
          embed_url: j?.html?.match(/src="([^"]+)"/)?.[1] ?? url,
          thumb_url: j?.thumbnail_url ?? null,
          title: j?.title ?? 'Video'
        };
      } catch {
        parsed = { provider: 'generic', embed_url: url, thumb_url: null, title: 'Video' };
      }
    }

    return NextResponse.json(parsed);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Parse error' }, { status: 400 });
  }
}
