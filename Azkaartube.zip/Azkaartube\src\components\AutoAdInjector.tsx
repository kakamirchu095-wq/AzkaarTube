'use client';

import React from "react";
import InlineAd from "./InlineAd";

interface AutoAdInjectorProps {
  content: string;
  adSlots: string[];
}

const AutoAdInjector = ({ content, adSlots }: AutoAdInjectorProps) => {
  // Split content into paragraphs
  const paragraphs = content.split("\n");

  // Inject ads after every 2 paragraphs (policy-friendly)
  let adIndex = 0;
  const contentWithAds = paragraphs.map((para, index) => {
    const isAdPlacement = (index + 1) % 2 === 0 && adIndex < adSlots.length;

    return (
      <React.Fragment key={index}>
        <p className="mb-4 leading-relaxed text-gray-300">{para}</p>
        {isAdPlacement && <InlineAd adSlot={adSlots[adIndex++]} />}
      </React.Fragment>
    );
  });

  return <div>{contentWithAds}</div>;
};

export default AutoAdInjector;
