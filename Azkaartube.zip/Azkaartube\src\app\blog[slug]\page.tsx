'use client';

import AutoAdInjector from "@/components/AutoAdInjector";

export default function BlogPost() {
  const blogContent = `
YouTube par success paane ka sabse pehla rule hai consistency.
Regularly videos upload karna zaroori hai taki algorithm aapko promote kare.

Thumbnails aur titles attractive hone chahiye taki audience click karein.
Achhi thumbnails engagement double kar deti hain.

Audience ke saath engage hona zaroori hai.
Comments ka reply dein aur community posts banayein.

Analytics ka use karein apne content ko improve karne ke liye.
Jahan audience drop hoti hai, wahan video me improvements karein.
  `;

  return (
    <div className="max-w-3xl mx-auto px-6 py-8 text-gray-200">
      <h1 className="text-3xl font-bold mb-6">Best Tips for YouTube Success</h1>
      <AutoAdInjector
        content={blogContent}
        adSlots={["2222222222", "3333333333", "5555555555"]}
      />
    </div>
  );
}
