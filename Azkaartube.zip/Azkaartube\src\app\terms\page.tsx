"use client";

export default function Terms() {
  return (
    <main className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Terms of Service</h1>
      <p>
        AzkaarTube use karte waqt aap hamare rules agree karte ho. Site par
        upload aur share kiya gaya content aapki zimmedari hai. Koi bhi illegal
        content allow nahi hai.
      </p>
    </main>
  );
}
