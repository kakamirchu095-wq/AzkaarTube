import "./globals.css";
import Link from "next/link";
import InlineAd from "@/components/InlineAd";

export const metadata = {
  title: "AzkaarTube",
  description: "Watch & share YouTube links easily"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#121212] text-gray-200">
        {/* 🔹 Navbar */}
        <header className="sticky top-0 z-20 bg-[#1E1E1E]/90 backdrop-blur border-b border-white/10">
          <div className="mx-auto max-w-6xl px-6 py-3 flex items-center gap-6">
            <Link href="/" className="font-extrabold text-2xl text-white">
              🎥 AzkaarTube
            </Link>
            <nav className="ml-auto flex items-center gap-6 text-sm font-medium">
              <Link href="/" className="hover:text-purple-400">Home</Link>
              <Link href="/about" className="hover:text-purple-400">About</Link>
              <Link href="/contact" className="hover:text-purple-400">Contact</Link>
            </nav>
          </div>
        </header>

        {/* 🔹 Top Ad Below Navbar */}
        <InlineAd adSlot="1111111111" />

        {/* 🔹 Main Page Content */}
        <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>

        {/* 🔹 Bottom Ad Above Footer */}
        <InlineAd adSlot="4444444444" />

        {/* 🔹 Footer */}
        <footer className="border-t border-white/10 bg-[#1E1E1E] py-6 mt-12">
          <div className="mx-auto max-w-6xl px-6 flex flex-col sm:flex-row items-center justify-between text-sm text-gray-400">
            <p>© {new Date().getFullYear()} AzkaarTube. All rights reserved.</p>
            <div className="flex gap-4 mt-3 sm:mt-0">
              <Link href="/privacy" className="hover:text-purple-400">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-purple-400">Terms of Service</Link>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
