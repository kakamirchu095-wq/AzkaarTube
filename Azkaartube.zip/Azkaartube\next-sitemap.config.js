
/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://azkaartube.vercel.app',
  generateRobotsTxt: true,
  sitemapSize: 5000,
  changefreq: 'daily',
  priority: 0.8,
  outDir: './public',
  robotsTxtOptions: {
    policies: [
      {
        userAgent: '*',
        allow: '/',
      },
    ],
    additionalSitemaps: [
      'https://azkaartube.vercel.app/video-sitemap.xml',
    ],
  },
};
