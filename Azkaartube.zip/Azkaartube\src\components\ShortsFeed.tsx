'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Heart, MessageCircle, Share2 } from 'lucide-react';

type Video = {
  id: string;
  title: string;
  video_link: string;
  embed_url: string;
  thumbnail_url: string;
  platform: string;
  created_at?: string;
};

export default function ShortsFeed({ videos }: { videos: Video[] }) {
  const shorts = videos.filter(
    (v) =>
      (v.platform === 'YouTube' && /shorts/.test(v.video_link)) ||
      v.platform === 'TikTok'
  );

  const [currentIndex, setCurrentIndex] = useState(0);
  const [likedVideos, setLikedVideos] = useState<Record<string, boolean>>({});
  const [heartAnim, setHeartAnim] = useState(false);

  const playerRefs = useRef<(HTMLIFrameElement | null)[]>([]);
  const touchStartY = useRef(0);

  const nextVideo = () =>
    setCurrentIndex((i) => Math.min(i + 1, shorts.length - 1));
  const prevVideo = () => setCurrentIndex((i) => Math.max(i - 1, 0));

  // Scroll wheel
  const handleWheel = (e: React.WheelEvent) => {
    if (e.deltaY > 0) nextVideo();
    else prevVideo();
  };

  // Swipe (mobile)
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.changedTouches[0].clientY;
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    const diff = touchStartY.current - e.changedTouches[0].clientY;
    if (diff > 50) nextVideo();
    if (diff < -50) prevVideo();
  };

  // Autoplay/pause videos
  useEffect(() => {
    playerRefs.current.forEach((iframe, i) => {
      if (!iframe) return;
      const message = JSON.stringify({
        event: 'command',
        func: i === currentIndex ? 'playVideo' : 'pauseVideo',
        args: [],
      });
      iframe.contentWindow?.postMessage(message, '*');
    });
  }, [currentIndex]);

  // Toggle Like button
  const toggleLike = (id: string) => {
    setLikedVideos((prev) => ({ ...prev, [id]: !prev[id] }));
    setHeartAnim(true);
    setTimeout(() => setHeartAnim(false), 900);
  };

  if (!shorts.length) {
    return (
      <div className="h-full w-full flex items-center justify-center bg-black text-white">
        No shorts available
      </div>
    );
  }

  return (
    <div
      className="h-full w-full bg-black overflow-hidden relative"
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {shorts.map((video, i) => {
        const isActive = i === currentIndex;
        const liked = likedVideos[video.id] || false;
        const embedAutoplay =
          video.embed_url +
          (video.embed_url.includes('?') ? '&' : '?') +
          'autoplay=1&controls=1&playsinline=1';

        return (
          <div
            key={video.id}
            className="absolute inset-0 transition-transform duration-500 ease-in-out"
            style={{ transform: `translateY(${(i - currentIndex) * 100}%)` }}
          >
            {/* Hidden iframe only when active to reduce resource usage */}
            {isActive && (
              <iframe
                ref={(el) => {
                  playerRefs.current[i] = el;
                }}
                src={embedAutoplay}
                title={video.title}
                className="w-full h-full"
                allow="autoplay; fullscreen"
              />
            )}

            {/* Overlay */}
            <div className="absolute inset-0 flex flex-col justify-end">
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

              <div className="relative z-10 w-full max-w-[900px] px-4 pb-20 flex items-end justify-between mx-auto text-white">
                <div className="flex-1 text-left">
                  <div className="text-sm opacity-80 mb-1">
                    {video.platform}
                  </div>
                  <div className="text-lg font-semibold line-clamp-2">
                    {video.title}
                  </div>
                </div>

                {/* Action buttons */}
                <div className="ml-4 flex flex-col items-center gap-6">
                  <button
                    title="Like"
                    className="flex flex-col items-center"
                    onClick={() => toggleLike(video.id)}
                  >
                    <Heart
                      className={`h-6 w-6 transition-colors ${
                        liked ? 'text-red-500' : 'text-white'
                      }`}
                    />
                    <span className="text-xs mt-1">Like</span>
                  </button>

                  <button
                    title="Comments"
                    className="flex flex-col items-center"
                    onClick={() => alert('Open comments modal (implement later)')}
                  >
                    <MessageCircle className="h-6 w-6" />
                    <span className="text-xs mt-1">Comment</span>
                  </button>

                  <button
                    title="Share"
                    className="flex flex-col items-center"
                    onClick={() => {
                      navigator.clipboard
                        ?.writeText(video.video_link)
                        .then(() => alert('Link copied'));
                    }}
                  >
                    <Share2 className="h-6 w-6" />
                    <span className="text-xs mt-1">Share</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Heart animation */}
            {heartAnim && liked && isActive && (
              <div className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none">
                <div className="text-white text-6xl animate-pop">❤️</div>
              </div>
            )}

            <style>{`
              .animate-pop { 
                animation: pop 900ms cubic-bezier(.2,.9,.3,1);
              }
              @keyframes pop {
                0%{ transform: scale(.3); opacity:0 } 
                50%{ transform: scale(1.15); opacity:1 } 
                100%{ transform: scale(1); opacity:0 } 
              }
            `}</style>
          </div>
        );
      })}
    </div>
  );
}
