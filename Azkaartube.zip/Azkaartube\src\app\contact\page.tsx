"use client";

export default function Contact() {
  return (
    <main className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Contact Us</h1>
      <p className="mb-2">
        Agar aapko koi suggestion ya query ho to hume contact karein:
      </p>
      <ul className="list-disc list-inside">
        <li>Email: support@azkaartube.com</li>
        <li>Facebook: fb.com/azkaartube</li>
        <li>Twitter: @azkaartube</li>
      </ul>
    </main>
  );
}
