'use client';

import React, { useState } from 'react';
import { useSwipeable } from 'react-swipeable';

type Video = {
  id: string;
  title: string;
  embed_url: string;
  thumbnail_url: string;
  video_link: string;
  platform: string;
};

export default function Shorts({ videos }: { videos: Video[] }) {
  // ✅ sirf shorts filter karo
  const shorts = videos.filter(
    (v) =>
      (v.platform?.toLowerCase() === 'youtube' && /shorts/.test(v.video_link)) ||
      v.platform?.toLowerCase() === 'tiktok'
  );
  const [current, setCurrent] = useState(0);

  const swipeHandlers = useSwipeable({
    onSwipedUp: () => setCurrent((p) => (p < shorts.length - 1 ? p + 1 : 0)),
    onSwipedDown: () => setCurrent((p) => (p > 0 ? p - 1 : shorts.length - 1)),
    preventScrollOnSwipe: true,
    trackTouch: true,
    trackMouse: true,
  });

  if (!shorts.length) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-56px)] text-gray-500">
        No shorts available
      </div>
    );
  }

  const video = shorts[current];

  return (
    <div
      {...swipeHandlers}
      className="relative w-full h-[calc(100vh-56px)] bg-black flex items-center justify-center overflow-hidden"
    >
      <iframe
        src={video.embed_url}
        title={video.title}
        className="w-full h-full max-w-[420px]"
        allowFullScreen
      />
      <div className="absolute bottom-16 left-4 right-4 text-white text-sm font-medium">
        {video.title}
      </div>
    </div>
  );
}
