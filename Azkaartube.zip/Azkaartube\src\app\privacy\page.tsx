"use client";

export default function Privacy() {
  return (
    <main className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Privacy Policy</h1>
      <p className="mb-2">
        AzkaarTube apke personal data ki protection ko serious leta hai. Hum
        user data kisi third party ko sell nahi karte. Hamari site par cookies
        use ho sakti hain jo better experience ke liye hoti hain.
      </p>
      <p>
        Agar aapko privacy ke related koi sawal ho to hume{" "}
        <strong>support@azkaartube.com</strong> par contact karein.
      </p>
    </main>
  );
}
