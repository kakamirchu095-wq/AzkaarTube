AzkaarTube-lite
================

A minimal production-ready Next.js project (no-auth) for uploading **video links** (YouTube, Vimeo, Facebook, Dailymotion, etc.) with automatic embed + thumbnail, AdSense & affiliate placeholders, and server-side parsing/insertion into Supabase.

How to use
1. Copy `.env.example` to `.env.local` and fill values (Supabase URL, anon key, service role key).
2. Install dependencies:
   ```
   npm install
   ```
3. Run locally:
   ```
   npm run dev
   ```
4. Build:
   ```
   npm run build
   ```
5. Deploy on Vercel and add environment variables in Project Settings.

Security note
- The project uses a server-side `/api/add` route that requires `SUPABASE_SERVICE_KEY` to insert into DB. Do NOT expose service key to the client.


YouTube API
-----------
For better YouTube metadata (HD thumbnails, duration, description) set `YOUTUBE_API_KEY` in your environment. Add it to `.env.local`.
