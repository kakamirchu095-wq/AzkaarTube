
/**
 * Example video sitemap generator.
 * Replace the `videos` array with dynamic data from your DB or CMS.
 * The script writes public/video-sitemap.xml
 */
const fs = require('fs');
const path = require('path');
const baseUrl = process.env.SITE_URL || 'https://azkaartube.vercel.app';

const videos = [
  // sample entry - replace with your real videos
  {
    title: 'Sample Dua - AzkaarTube',
    description: 'Sample description for video. Replace with real data.',
    thumbnail: `${baseUrl}/thumbnails/sample.jpg`,
    url: `${baseUrl}/video/sample`,
    duration: '90',
    uploadDate: '2025-09-09',
  }
];

let videoXml = `<?xml version="1.0" encoding="UTF-8"?>
`;
videoXml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">\n`;

videos.forEach(v => {
  videoXml += `  <url>\n`;
  videoXml += `    <loc>${v.url}</loc>\n`;
  videoXml += `    <video:video>\n`;
  videoXml += `      <video:title><![CDATA[${v.title}]]></video:title>\n`;
  videoXml += `      <video:description><![CDATA[${v.description}]]></video:description>\n`;
  videoXml += `      <video:thumbnail_loc>${v.thumbnail}</video:thumbnail_loc>\n`;
  videoXml += `      <video:duration>${v.duration}</video:duration>\n`;
  videoXml += `      <video:publication_date>${v.uploadDate}</video:publication_date>\n`;
  videoXml += `    </video:video>\n`;
  videoXml += `  </url>\n`;
});

videoXml += `</urlset>`;

const out = path.join(__dirname, '..', 'public', 'video-sitemap.xml');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, videoXml, 'utf8');
console.log('✅ video-sitemap.xml generated at', out);
