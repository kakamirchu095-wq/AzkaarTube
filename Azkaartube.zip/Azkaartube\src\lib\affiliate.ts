export function withAffiliate(url: string) {
  const id = process.env.NEXT_PUBLIC_AFFILIATE_ID;
  if (!id) return url;
  try {
    const u = new URL(url);
    if (/amazon\./.test(u.hostname)) {
      if (!u.searchParams.get('tag')) u.searchParams.set('tag', id);
      return u.toString();
    }
    if (/daraz\.pk/.test(u.hostname)) {
      if (!u.searchParams.get('aff_id')) u.searchParams.set('aff_id', id);
      return u.toString();
    }
    return url;
  } catch {
    return url;
  }
}
