"use client";

import { useEffect, useRef } from "react";

interface AdSenseProps {
  adSlot: string;
  style?: React.CSSProperties;
}

const AdSense = ({ adSlot, style }: AdSenseProps) => {
  const adRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      // Prevent duplicate ad injection
      if (adRef.current && adRef.current.children.length === 0) {
        // @ts-ignore
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      }
    } catch (err) {
      console.error("AdSense error:", err);
    }
  }, []);

  return (
    <ins
      ref={adRef as any}
      className="adsbygoogle"
      style={{
        display: "block",
        width: "100%",
        minHeight: "250px", // ✅ Prevent slot size error
        textAlign: "center",
        ...style,
      }}
      data-ad-client="ca-pub-8857639892821423"  // 👈 Replace with your real Client ID
      data-ad-slot={adSlot}                     // 👈 Replace with your real Ad Slot ID
      data-ad-format="auto"
      data-full-width-responsive="true"
    ></ins>
  );
};

export default AdSense;
