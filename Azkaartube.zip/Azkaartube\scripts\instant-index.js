
/**
 * Instant Indexing example using Google Indexing API.
 * IMPORTANT: Enable Indexing API in Google Cloud Console and create a service account key JSON.
 * Do NOT commit the google-api-key.json to git. Place it in project root.
 *
 * To run: node scripts/instant-index.js https://azkaartube.vercel.app/video/sample
 */
const { google } = require('googleapis');
const path = require('path');

async function run() {
  const url = process.argv[2];
  if (!url) {
    console.error('Usage: node scripts/instant-index.js <URL_TO_INDEX>');
    process.exit(1);
  }

  const keyPath = path.join(process.cwd(), 'google-api-key.json');
  if (!require('fs').existsSync(keyPath)) {
    console.error('google-api-key.json not found in project root. Please create and download from Google Cloud Console.');
    process.exit(1);
  }

  const key = require(keyPath);

  const auth = new google.auth.JWT(
    key.client_email,
    null,
    key.private_key,
    ['https://www.googleapis.com/auth/indexing']
  );

  const indexing = google.indexing({ version: 'v3', auth });

  try {
    const res = await indexing.urlNotifications.publish({
      requestBody: {
        url,
        type: 'URL_UPDATED'
      }
    });
    console.log('✅ Indexing API response:', res.data);
  } catch (err) {
    console.error('Indexing API error:', err.response ? err.response.data : err.message);
  }
}

run();
